<?php 
$menus = 
array (
  'footer-menu' => 
  array (
    'name' => 'Footer Menu',
    'is_mega' => 0,
    'mega_item' => '',
    'columns_item' => '',
    'children' => 
    array (
      'i-1162' => 
      array (
        'order' => '1',
        'title' => 'Home',
        'type' => 'page',
        'url' => '#',
        'page' => 'homepage',
      ),
      'i-1163' => 
      array (
        'order' => '2',
        'type' => 'page',
        'url' => '#',
        'page' => 'contact-us',
      ),
    ),
  ),
  'primary' => 
  array (
    'name' => 'Main Menu',
    'is_mega' => 0,
    'mega_item' => '',
    'columns_item' => '',
    'children' => 
    array (
      'i-1164' => 
      array (
        'order' => '4',
        'title' => 'PLAYLISTS',
        'type' => 'page',
        'url' => '#',
        'page' => 'playlists',
      ),
      'i-1165' => 
      array (
        'order' => '2',
        'title' => 'CHANNELS',
        'type' => 'page',
        'url' => '#',
        'page' => 'channels',
      ),
      'i-1167' => 
      array (
        'order' => '5',
        'title' => 'STARS',
        'type' => 'page',
        'url' => '#',
        'page' => 'actor-listing',
      ),
      'i-1169' => 
      array (
        'order' => '3',
        'title' => 'SERIES',
        'type' => 'page',
        'url' => '#',
        'page' => 'all-series',
      ),
      'i-1187' => 
      array (
        'order' => '1',
        'title' => 'HOME',
        'type' => 'page',
        'url' => '#',
        'page' => 'homepage',
      ),
    ),
  ),
  'user-menu' => 
  array (
    'name' => 'User Menu',
    'is_mega' => 0,
    'mega_item' => '',
    'columns_item' => '',
    'children' => 
    array (
      'i-1168' => 
      array (
        'order' => '1',
        'type' => 'page',
        'url' => '#',
        'page' => 'subscribed-channels',
      ),
    ),
  ),
);
