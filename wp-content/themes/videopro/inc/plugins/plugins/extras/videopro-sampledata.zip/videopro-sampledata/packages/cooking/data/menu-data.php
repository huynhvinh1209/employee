<?php 
$menus = 
array (
  'custom-menu' => 
  array (
    'name' => 'Custom Menu',
    'is_mega' => 0,
    'mega_item' => '',
    'columns_item' => '',
    'children' => 
    array (
      'i-660' => 
      array (
        'order' => '1',
        'title' => 'About VideoPro',
        'type' => 'custom',
        'url' => '#',
      ),
      'i-661' => 
      array (
        'order' => '2',
        'title' => 'WordPress Theme',
        'type' => 'custom',
        'url' => '#',
      ),
      'i-662' => 
      array (
        'order' => '3',
        'title' => 'Submit Your Video',
        'type' => 'custom',
        'url' => '#',
      ),
      'i-663' => 
      array (
        'order' => '4',
        'title' => 'Terms and Privacy',
        'type' => 'custom',
        'url' => '#',
      ),
      'i-664' => 
      array (
        'order' => '5',
        'title' => 'For Advertisers',
        'type' => 'custom',
        'url' => '#',
      ),
      'i-666' => 
      array (
        'order' => '6',
        'title' => 'Contact Us',
        'type' => 'custom',
        'url' => '#',
      ),
    ),
  ),
  'footer-menu' => 
  array (
    'name' => 'Footer Menu',
    'is_mega' => 0,
    'mega_item' => '',
    'columns_item' => '',
    'children' => 
    array (
      'i-671' => 
      array (
        'order' => '1',
        'type' => 'page',
        'url' => '#',
        'page' => 'home-page',
      ),
      'i-672' => 
      array (
        'order' => '2',
        'type' => 'page',
        'url' => '#',
        'page' => 'channel-list',
      ),
      'i-673' => 
      array (
        'order' => '3',
        'type' => 'page',
        'url' => '#',
        'page' => 'chefs-list',
      ),
    ),
  ),
  'primary' => 
  array (
    'name' => 'Main Menu',
    'is_mega' => 0,
    'mega_item' => '',
    'columns_item' => '',
    'children' => 
    array (
      'i-287' => 
      array (
        'order' => '1',
        'title' => 'HOME',
        'type' => 'page',
        'url' => '#',
        'page' => 'home-page',
      ),
      'i-330' => 
      array (
        'order' => '4',
        'title' => 'CHEFS',
        'type' => 'page',
        'url' => '#',
        'page' => 'chefs-list',
      ),
      'i-380' => 
      array (
        'order' => '2',
        'title' => 'CHANNELS',
        'type' => 'page',
        'url' => '#',
        'page' => 'channel-list',
      ),
      'i-655' => 
      array (
        'order' => '3',
        'title' => 'PLAYLISTS',
        'type' => 'page',
        'url' => '#',
        'page' => 'playlist-listing',
      ),
    ),
  ),
);
